<?php /* C:\xampp\htdocs\quick_count_new\resources\views/admin/lembaga/form.blade.php */ ?>
<div class="row mB-40">
	<div class="col-sm-12">
		<div class="bgc-white p-20 bd">
			<?php echo Form::myInput('text', 'nama', 'Nama'); ?>

		
				<?php echo Form::mySelect('prov_id', 'Provinsi', $provinsi_untuk_select2, isset($item->prov_id) ? $item->prov_id : null, ['class' => 'form-control select2']); ?>	
		
				<?php echo Form::mySelect('kab_id', 'Kabupaten', $kabupaten_untuk_select2, isset($item->kab_id) ? $item->kab_id : null, ['class' => 'form-control select2']); ?>

		
				<?php echo Form::mySelect('kec_id', 'Kecamatan', $kecamatan_untuk_select2, isset($item->kec_id) ? $item->kec_id : null, ['class' => 'form-control select2']); ?>


				<?php echo Form::myTextArea('alamat', 'Alamat'); ?>


				<?php echo Form::myInput('kontak', 'kontak', 'Kontak'); ?>

		
				<?php echo Form::mySelect('status', 'Status', config('variables.status'), isset($item->status) ? $item->status : null, ['class' => 'form-control select2']); ?>


				<?php echo Form::mySelect('jenis', 'Jenis', config('variables.jenis'), isset($item->jenis) ? $item->jenis : null, ['class' => 'form-control select2']); ?>

				
		
				

				

				
				
				
		</div>  
	</div>
</div>