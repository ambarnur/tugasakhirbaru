<?php /* C:\xampp\htdocs\quick_count_new\resources\views/admin_lembaga/users/form.blade.php */ ?>
<div class="row mB-40">
	<div class="col-sm-12">
		<div class="bgc-white p-20 bd">
			<?php echo Form::myInput('text', 'nama', 'Nama'); ?>

		
				<?php echo Form::myInput('email', 'email', 'Email'); ?>

		
				<?php echo Form::myInput('password', 'password', 'Password'); ?>

		
				<?php echo Form::myInput('password', 'password_confirmation', 'Tulis ulang password'); ?>


				<?php echo Form::myInput('nik', 'nik', 'NIK'); ?>


				<?php echo Form::myInput('kontak', 'kontak', 'Kontak'); ?>

		
				<?php echo Form::myTextArea('bio', 'Biodata'); ?>


				<?php echo Form::myFile('avatar', 'Foto'); ?>


				<?php echo Form::myInput('hidden', 'role', '', array(), 20); ?>


				<?php echo Form::myInput('hidden', 'lembaga_id', '', array(), Auth::user()->lembaga_id); ?>

				
				
		</div>  
	</div>
</div>