<?php /* C:\xampp\htdocs\quick_count_new\resources\views/admin/partials/menu.blade.php */ ?>
<?php
    $r = \Route::current()->getAction();
    $route = (isset($r['as'])) ? $r['as'] : '';
?>

<li class="nav-item mT-30">
    <a class="sidebar-link <?php echo e(starts_with($route, ADMIN . '.dash') ? 'active' : ''); ?>" href="<?php echo e(route(ADMIN . '.dash')); ?>">
        <span class="icon-holder">
            <i class="c-brown-500 ti-home"></i>
        </span>
        <span class="title">Dashboard</span>
    </a>
</li>
<li class="nav-item">
    <a class="sidebar-link <?php echo e(starts_with($route, ADMIN . '.users') ? 'active' : ''); ?>" href="<?php echo e(route(ADMIN . '.users.index')); ?>">
        <span class="icon-holder">
            <i class="c-brown-500 ti-user"></i>
        </span>
        <span class="title">Users</span>
    </a>
</li>
<li class="nav-item">
    <a class="sidebar-link <?php echo e(starts_with($route, ADMIN . '.lembaga') ? 'active' : ''); ?>" href="<?php echo e(route(ADMIN . '.lembaga.index')); ?>">
        <span class="icon-holder">
            <i class="c-brown-500 fa fa-institution"></i>
        </span>
        <span class="title">Lembaga Survey</span>
    </a>
</li>
<li class="nav-item">
    <a class="sidebar-link <?php echo e(starts_with($route, ADMIN . '.pemilihan') ? 'active' : ''); ?>" href="<?php echo e(route(ADMIN . '.pemilihan.index')); ?>">
        <span class="icon-holder">
            <i class="c-brown-500 fa fa-pencil"></i>
        </span>
        <span class="title">Pemilihan</span>
    </a>
</li>