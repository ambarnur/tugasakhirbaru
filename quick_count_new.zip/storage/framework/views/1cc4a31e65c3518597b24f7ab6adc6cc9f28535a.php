<?php /* C:\xampp\htdocs\quick_count\resources\views/admin/users/lembaga.blade.php */ ?>
<div class="row mB-40">
	<div class="col-sm-8">
		<div class="bgc-white p-20 bd">
			<?php echo Form::myInput('text', 'nama', 'Nama Lembaga'); ?>

				<?php echo Form::myInput('text', 'Provinsi'); ?>

		
				<?php echo Form::myInput('text', 'Kabupaten'); ?>

		
				<?php echo Form::myInput('text', 'Kecamatan'); ?>

		
				<?php echo Form::myInput('text', 'Alamat Kantor'); ?>


				<?php echo Form::myInput('text', 'Kontak'); ?>

		
				<?php echo Form::mySelect('Jenis', 'Jenis', null, ['class' => 'form-control select2']); ?>

		
				<?php echo Form::mySelect('Status', 'Status', null, ['class' => 'form-control select2']); ?>

		</div>  
	</div>
</div>