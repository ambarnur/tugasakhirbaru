<?php /* C:\xampp\htdocs\quick_count_new\resources\views/admin/calon/edit.blade.php */ ?>
<?php $__env->startSection('page-header'); ?>
	Pemilihan <small><?php echo e(trans('app.update_item')); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::model($item, [
			'action' => ['CalonController@update', $item->id],
			'method' => 'put', 
			'files' => true
		]); ?>


		<?php echo $__env->make('admin.calon.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<button type="submit" class="btn btn-primary"><?php echo e(trans('Submit')); ?></button>
		<button type="submit" class="btn btn-danger"><?php echo e(trans('Cancel')); ?></button>
		
	<?php echo Form::close(); ?>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>