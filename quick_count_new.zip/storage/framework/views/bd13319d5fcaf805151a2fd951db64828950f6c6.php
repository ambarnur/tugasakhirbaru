<?php /* C:\xampp\htdocs\quick_count_new\resources\views/admin/users/create.blade.php */ ?>
<?php $__env->startSection('page-header'); ?>
<div class="bgc-white bd bdrs-3 pB-50 mB-20">        
		<h4 class="pull-left mL-10 mT-5"> Tambah User Baru </h4>
        <a href="<?php echo e(route(ADMIN . '.users.index')); ?>" class="btn btn-secondary pull-right mR-10 mT-5">
            <i class="fa fa-arrow-left"></i> Kembali
        </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::open([
			'action' => ['UserController@store'],
			'files' => true
		]); ?>


		<?php echo $__env->make('admin.users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
		
	<?php echo Form::close(); ?>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>