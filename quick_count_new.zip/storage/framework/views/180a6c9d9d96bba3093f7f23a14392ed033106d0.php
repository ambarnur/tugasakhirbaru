<?php /* C:\xampp\htdocs\quick_count_new\resources\views/admin_lembaga/tps/edit.blade.php */ ?>
<?php $__env->startSection('page-header'); ?>
	Tps <small><?php echo e(trans('app.update_item')); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::model($item, [
			'action' => ['Admin_lembaga\TpsController@update', $item->id],
			'method' => 'put', 
			'files' => true
		]); ?>


		<?php echo $__env->make('admin_lembaga.tps.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<button type="submit" class="btn btn-primary"><?php echo e(trans('Submit')); ?></button>
		<button type="submit" class="btn btn-danger"><?php echo e(trans('Cancel')); ?></button>
		
	<?php echo Form::close(); ?>

	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	$(document).ready( function() {
		$("select[name='prov_id']").change(function(){
			var provinsi_id = $(this).val();
			var token = $("input[name='_token']").val();
			$.ajax({
				url: "<?php echo e(url('get_kabupaten_by_provinsi')); ?>",
				method: 'POST',
				data: {provinsi_id:provinsi_id, _token:token},
				success: function(data){
					var toAppend = '';
					$("select[name='kab_id']").empty();
					for (var key in data) {
						if (data.hasOwnProperty(key)) {
							toAppend += '<option value="'+ key +'">'+data[key]+'</option>';
						}
					}
					$("select[name='kab_id']").append(toAppend);					

				},
				error: function(msg){
					console.log(msg);
				}
			});
		});

		$("select[name='kab_id']").change(function(){
			var kabupaten_id = $(this).val();
			var token = $("input[name='_token']").val();
			$.ajax({
				url: "<?php echo e(url('get_kecamatan_by_kabupaten')); ?>",
				method: 'POST',
				data: {kabupaten_id:kabupaten_id, _token:token},
				success: function(data){
					var toAppend = '';
					$("select[name='kec_id']").empty();
					for (var key in data) {
						if (data.hasOwnProperty(key)) {
							toAppend += '<option value="'+ key +'">'+data[key]+'</option>';
						}
					}
					$("select[name='kec_id']").append(toAppend);					

				},
				error: function(msg){
					console.log(msg);
				}
			});
		});

		$("select[name='kec_id']").change(function(){
			var kecamatan_id = $(this).val();
			var token = $("input[name='_token']").val();
			$.ajax({
				url: "<?php echo e(url('get_kelurahan_by_kecamatan')); ?>",
				method: 'POST',
				data: {kecamatan_id:kecamatan_id, _token:token},
				success: function(data){
					var toAppend = '';
					$("select[name='kel_id']").empty();
					for (var key in data) {
						if (data.hasOwnProperty(key)) {
							toAppend += '<option value="'+ key +'">'+data[key]+'</option>';
						}
					}
					$("select[name='kel_id']").append(toAppend);					

				},
				error: function(msg){
					console.log(msg);
				}
			});
		});
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_lembaga.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>