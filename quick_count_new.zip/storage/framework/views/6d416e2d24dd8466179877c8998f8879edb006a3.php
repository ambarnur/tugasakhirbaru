<?php /* C:\xampp\htdocs\quick_count_new\resources\views/admin/pemilihan/form.blade.php */ ?>
<div class="row mB-40">
	<div class="col-sm-12">
		<div class="bgc-white p-20 bd">
		<?php echo Form::mySelect('jenis', 'Jenis Pemilihan', config('variables.jenis_pil'), isset($item->jenis) ? $item->jenis : null, ['class' => 'form-control select2']); ?>

		
				<?php echo Form::myInput('tahun', 'tahun', 'Tahun'); ?>


				<?php echo Form::mySelect('prov_id', 'Provinsi', $provinsi_untuk_select2, isset($item->prov_id) ? $item->prov_id : null, ['class' => 'form-control select2']); ?>

		
				<?php echo Form::mySelect('kab_id', 'Kabupaten', $kabupaten_untuk_select2, isset($item->kab_id) ? $item->kab_id : null, ['class' => 'form-control select2']); ?>

				
				
		</div>  
	</div>
</div>