<?php /* C:\xampp\htdocs\quick_count\resources\views/admin/users/form.blade.php */ ?>
<div class="row mB-40">
	<div class="col-sm-12">
		<div class="bgc-white p-20 bd">
			<?php echo Form::myInput('text', 'nama', 'Nama'); ?>

		
				<?php echo Form::myInput('email', 'email', 'Email'); ?>

		
				<?php echo Form::myInput('password', 'password', 'Password'); ?>

		
				<?php echo Form::myInput('password', 'password_confirmation', 'Tulis ulang password'); ?>


				<?php echo Form::myInput('nik', 'nik', 'NIK'); ?>


				<?php echo Form::myInput('kontak', 'kontak', 'Kontak'); ?>

		
				<?php echo Form::mySelect('role', 'Role', config('variables.role'), isset($item->role) ? $item->role : null, ['class' => 'form-control select2']); ?>

				<?php echo Form::mySelect('lembaga_id', 'Lembaga', $lembaga_survey_untuk_select2, isset($item->lembaga_id) ? $item->lembaga_id : null, ['class' => 'form-control select2']); ?>

		
				<?php echo Form::myTextArea('bio', 'Biodata'); ?>


				<?php echo Form::myFile('avatar', 'Foto'); ?>


				
				
				
		</div>  
	</div>
</div>