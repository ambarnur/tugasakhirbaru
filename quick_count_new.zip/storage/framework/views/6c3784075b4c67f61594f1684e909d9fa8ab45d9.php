<?php /* C:\xampp\htdocs\quick_count_new\resources\views/admin/calon/index.blade.php */ ?>
<?php $__env->startSection('page-header'); ?>
    Calon <small><?php echo e(trans('app.manage')); ?></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bgc-white bd bdrs-3 pB-50">
        <h4 class="pull-left mL-10 mT-5"> Tabel Calon Pemilihan <?php echo e($pemilihan->jenis); ?> <?php echo e($pemilihan->provinsi->nama); ?> <?php echo e($pemilihan->kabupaten->nama); ?> <?php echo e($pemilihan->tahun); ?></h4>
        <a href="<?php echo e(url('/admin/pemilihan/calon/create', $id)); ?>" class="btn btn-info pull-right mR-10 mT-5">
            <i class="fa fa-arrow-left"></i> Kembali
        </a>
        <a href="<?php echo e(url('/admin/pemilihan/calon/create', $id)); ?>" class="btn btn-info pull-right mR-10 mT-5">
            <i class="fa fa-plus"></i> <?php echo e(trans('app.add_button')); ?>

        </a>
    </div>
    <div class="bgc-white bd bdrs-3 p-20 mB-20">
        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Nomor Urut</th>
                    <th>Nama Calon Utama</th>
                    <th>Nama Calon Wakil</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><a href="#"><?php echo e($item->calon_nomor_urut); ?></a></td>
                        <td><?php echo e($item->calon_utama_nama); ?></td>
                        <td>    
                                <?php echo e($item->calon_wakil_nama); ?>

                        </td>

                        <td>
                            <ul class="list-inline">
                                
                                <li class="list-inline-item">
                                    <a href="<?php echo e(url('/admin/pemilihan/calon/edit', $item->id)); ?>" title="<?php echo e(trans('app.edit_title')); ?>" class="btn btn-primary btn-sm"><span class="ti-pencil"></span></a></li>
                                <li class="list-inline-item">
                                    <?php echo Form::open([
                                        'class'=>'delete',
                                        'url'  => url('/admin/pemilihan/calon', $item->id), 
                                        'method' => 'DELETE',
                                        ]); ?>


                                        <button class="btn btn-danger btn-sm" title="<?php echo e(trans('app.delete_title')); ?>"><i class="ti-trash"></i></button>
                                        
                                    <?php echo Form::close(); ?>

                                </li> 
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>