<?php /* C:\xampp\htdocs\quick_count_new\resources\views/admin_lembaga/partials/menu.blade.php */ ?>
<?php
    $r = \Route::current()->getAction();
    $route = (isset($r['as'])) ? $r['as'] : '';
?>

<li class="nav-item mT-30">
    <a class="sidebar-link <?php echo e(starts_with($route, 'admin_lembaga' . '.dash') ? 'active' : ''); ?>" href="<?php echo e(route('admin_lembaga' . '.dash')); ?>">
        <span class="icon-holder">
            <i class="c-brown-500 ti-home"></i>
        </span>
        <span class="title">Dashboard</span>
    </a>
</li>
<li class="nav-item">
    <a class="sidebar-link <?php echo e(starts_with($route, 'admin_lembaga' . '.users') ? 'active' : ''); ?>" href="<?php echo e(route('admin_lembaga' . '.users.index')); ?>">
        <span class="icon-holder">
            <i class="c-brown-500 ti-user"></i>
        </span>
        <span class="title">Saksi TPS</span>
    </a>
</li>
<li class="nav-item">
    <a class="sidebar-link <?php echo e(starts_with($route, 'admin_lembaga' . '.pemilihan') ? 'active' : ''); ?>" href="<?php echo e(route('admin_lembaga' . '.pemilihan.index')); ?>">
        <span class="icon-holder">
            <i class="c-brown-500 fa fa-pencil"></i>
        </span>
        <span class="title">Pemilihan</span>
    </a>
</li>
<li class="nav-item">
    <a class="sidebar-link <?php echo e(starts_with($route, 'admin_lembaga' . '.tps') ? 'active' : ''); ?>" href="<?php echo e(route('admin_lembaga' . '.tps.index')); ?>">
        <span class="icon-holder">
            <i class="c-brown-500 fa fa-address-card"></i>
        </span>
        <span class="title">Data TPS</span>
    </a>
</li>