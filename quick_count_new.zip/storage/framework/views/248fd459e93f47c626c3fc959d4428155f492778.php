<?php /* C:\xampp\htdocs\quick_count_new\resources\views/admin/calon/form.blade.php */ ?>
<div class="row mB-40">
	<div class="col-sm-12">
		<div class="bgc-white p-20 bd">
		<?php echo Form::myInput('hidden','pemilihan_id','',array(),$id); ?>

		<?php echo Form::myInput('calon_nomor_urut', 'calon_nomor_urut', 'Nomor Urut'); ?>

		
				<?php echo Form::myInput('calon_utama_nama', 'calon_utama_nama', 'Nama Calon Utama'); ?>


				<?php echo Form::myInput('calon_wakil_nama', 'calon_wakil_nama', 'Nama Calon Wakil'); ?>


		</div>  
	</div>
</div>