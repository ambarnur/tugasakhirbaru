<div class="row mB-40">
	<div class="col-sm-12">
		<div class="bgc-white p-20 bd">
		{!! Form::myInput('hidden','pemilihan_id','',array(),$id) !!}
		{!! Form::myInput('calon_nomor_urut', 'calon_nomor_urut', 'Nomor Urut') !!}
		
				{!! Form::myInput('calon_utama_nama', 'calon_utama_nama', 'Nama Calon Utama') !!}

				{!! Form::myInput('calon_wakil_nama', 'calon_wakil_nama', 'Nama Calon Wakil') !!}

		</div>  
	</div>
</div>